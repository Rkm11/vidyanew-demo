<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Telecalling extends Model
{
    public $fillable =['student_name','mobile','follow1','follow2','follow3','follow4','follow5'];
}
